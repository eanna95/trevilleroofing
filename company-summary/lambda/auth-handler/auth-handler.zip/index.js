const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');

const ssmClient = new SSMClient({ 
  region: process.env.AWS_REGION || 'us-east-1'
});

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { username, password } = body;

    if (!username || !password) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Username and password are required' })
      };
    }

    // Fetch stored credentials from Parameter Store
    const [usernameResponse, passwordResponse] = await Promise.all([
      ssmClient.send(new GetParameterCommand({
        Name: '/treville-demo/auth/username',
        WithDecryption: false
      })),
      ssmClient.send(new GetParameterCommand({
        Name: '/treville-demo/auth/password',
        WithDecryption: true
      }))
    ]);

    const storedUsername = usernameResponse.Parameter?.Value;
    const storedPassword = passwordResponse.Parameter?.Value;

    if (!storedUsername || !storedPassword) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Authentication configuration not found' })
      };
    }

    // Validate credentials
    const isValid = storedUsername === username && storedPassword === password;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        valid: isValid,
        message: isValid ? 'Authentication successful' : 'Invalid credentials'
      })
    };

  } catch (error) {
    console.error('Authentication error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: 'Authentication service temporarily unavailable'
      })
    };
  }
};